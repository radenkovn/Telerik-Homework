﻿namespace Factory_Method.Classes.Products
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class Milka : Chocolate
    {
        public Milka(string name)
            : base(name)
        {

        }
    }
}
