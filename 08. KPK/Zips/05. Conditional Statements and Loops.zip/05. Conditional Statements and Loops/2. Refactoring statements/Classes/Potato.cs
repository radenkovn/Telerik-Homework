﻿namespace RefactoringStatements.Classes
{
    class Potato
    {
        public bool HasNotBeenPeeled { get; set; }
        public bool IsRotten { get; set; }
    }
}
