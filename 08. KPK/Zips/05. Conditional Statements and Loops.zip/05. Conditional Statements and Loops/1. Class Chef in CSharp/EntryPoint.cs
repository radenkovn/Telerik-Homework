﻿namespace ClassChefExercise
{
    using System;
    class EntryPoint
    {
        static void Main()
        {
            //Please Open the "Chef.cs" file
        }
    }
}
