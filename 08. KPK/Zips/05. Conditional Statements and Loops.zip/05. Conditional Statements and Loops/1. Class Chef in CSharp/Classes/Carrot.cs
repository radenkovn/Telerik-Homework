﻿namespace ClassChefExercise.Classes
{
    class Carrot
    {
    }
}
