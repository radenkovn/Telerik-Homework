﻿namespace ClassChefExercise.Classes
{
    class Potato
    {
    }
}
