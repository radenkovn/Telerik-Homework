﻿using System;
namespace ClassChefExercise.Classes
{
    class Bowl
    {
        internal void Add(Carrot carrot)
        {
            throw new NotImplementedException();
        }

        internal void Add(Potato potato)
        {
            throw new NotImplementedException();
        }
    }
}
