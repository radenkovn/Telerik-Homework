﻿using System;
namespace ClassChefExercise.Classes
{
    class Vegetable
    {
    }
}
