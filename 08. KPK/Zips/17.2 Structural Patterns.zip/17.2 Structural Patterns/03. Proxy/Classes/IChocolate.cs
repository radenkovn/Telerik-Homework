﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proxy.Classes
{
    interface IChocolate
    {
        string ChocolateType;

        string MilkTYpe;

        string Width;

        string Height;

        string Weight;

        string Brand;
    
    }
}
