﻿using System;
namespace RenameHumanClass.Classes
{
    using RenameHumanClass.Enums;
    class Human
    {
        public Gender Gender { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
