﻿namespace RenameHumanClass.Enums
{
    enum Gender { Male, Female };
}
