﻿

public class Test
{
		public int TestProperty0 { get; set; }
		public int TestProperty1 { get; set; }
		public int TestProperty2 { get; set; }
		public int TestProperty3 { get; set; }
		public int TestProperty4 { get; set; }
		public int TestProperty5 { get; set; }
		public int TestProperty6 { get; set; }
		public int TestProperty7 { get; set; }
		public int TestProperty8 { get; set; }
		public int TestProperty9 { get; set; }
		public int TestProperty10 { get; set; }
		public int TestProperty11 { get; set; }
		public int TestProperty12 { get; set; }
		public int TestProperty13 { get; set; }
		public int TestProperty14 { get; set; }
		public int TestProperty15 { get; set; }
		public int TestProperty16 { get; set; }
		public int TestProperty17 { get; set; }
		public int TestProperty18 { get; set; }
		public int TestProperty19 { get; set; }
	}

public class Test1
{
	public Test CurrentTest { get; set; }

}
public class Test2
{
	public Test CurrentTest { get; set; }

}
public class Test3
{
	public Test CurrentTest { get; set; }

}
