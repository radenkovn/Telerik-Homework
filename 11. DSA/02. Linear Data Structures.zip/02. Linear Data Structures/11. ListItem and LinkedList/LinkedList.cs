﻿namespace _11.ListItem_and_LinkedList
{
    public class LinkedList<T>
    {
        public ListItem<T> FirstElement { get; set; }
    }
}
