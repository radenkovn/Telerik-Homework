﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentClass.Classes.Enums
{
    public enum Faculties
    {
        Math, Physics, Biology, Medicine, Chemistry, Linguistics
    }
}
