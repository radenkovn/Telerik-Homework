﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentClass.Classes.Enums
{
    public enum Universities
    {
        SofiaUni, TechUni, PlovdivUni, TurnovoUni
    }
}
