﻿namespace BankAccounts.Classes.Accounts.Interfaces
{
    interface IWithdrawable
    {
        void WithDraw(decimal amount);
    }
}
