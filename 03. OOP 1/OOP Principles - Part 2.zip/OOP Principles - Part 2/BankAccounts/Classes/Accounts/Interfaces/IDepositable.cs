﻿namespace BankAccounts.Classes.Accounts.Interfaces
{
    public interface IDepositable
    {
        void DepositMoney(decimal amount);
    }
}
