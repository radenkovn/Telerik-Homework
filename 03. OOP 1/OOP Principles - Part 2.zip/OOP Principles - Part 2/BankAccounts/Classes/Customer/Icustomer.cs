﻿namespace BankAccounts.Classes.Customer
{
    public interface ICustomer
    {
        string Name { get; }
        bool Individual { get; }
    }
}
