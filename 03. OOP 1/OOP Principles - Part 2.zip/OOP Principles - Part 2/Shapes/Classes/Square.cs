﻿namespace Shapes.Classes
{
    class Square : Rectanle
    {
        public Square(double width)
            : base(width, width)
        {

        }
    }
}
