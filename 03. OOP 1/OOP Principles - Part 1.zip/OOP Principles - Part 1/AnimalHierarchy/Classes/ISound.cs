﻿namespace AnimalHierarchy.Classes
{
    interface ISound
    {
        string Sound();
    }
}
