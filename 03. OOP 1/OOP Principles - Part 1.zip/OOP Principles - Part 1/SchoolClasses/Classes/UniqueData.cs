﻿namespace SchoolClasses
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    public static class UniqueData
    {
        //Unique names of classes and numbers of students
        public static List<string> allClassNames = new List<string>();
        public static List<int> studentNumbers = new List<int>();
    }
}
