--04. Write a SQL query to find all information about all departments (use "TelerikAcademy" database).
SELECT * FROM dbo.Departments