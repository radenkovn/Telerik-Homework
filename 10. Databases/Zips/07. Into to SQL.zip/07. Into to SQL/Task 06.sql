--Write a SQL query to find the salary of each employee.
SELECT Employees.Salary
FROM dbo.Employees