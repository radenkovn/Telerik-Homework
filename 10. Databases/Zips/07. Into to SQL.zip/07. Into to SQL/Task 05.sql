--05. Write a SQL query to find all department names.
SELECT Departments.Name
FROM dbo.Departments