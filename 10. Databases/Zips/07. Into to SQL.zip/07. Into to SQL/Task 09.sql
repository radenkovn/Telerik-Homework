-- Write a SQL query to find all different employee salaries.
SELECT DISTINCT Employees.Salary
FROM dbo.Employees