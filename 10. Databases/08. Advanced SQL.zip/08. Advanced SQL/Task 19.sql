--Write SQL statements to insert several records in the Users and Groups tables.


INSERT INTO Users (Username, Password, [Full Name])
VALUES('harryp', 'asdqwe', 'Harry Potter'),
		('ronaldw', 'qweqasd', 'Ronald Weasley')

INSERT INTO Groups (Name)
VALUES ('Transfiguration'),
		('Alchemy')